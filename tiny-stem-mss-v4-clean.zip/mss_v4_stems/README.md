# Tiny Stem MSS v4

v4 troca o problema de um unico separador 4-way por modelos pequenos especializados:

- `vocals.pt`: vocals vs residual/accompaniment;
- `drums.pt`: drums vs residual;
- `bass.pt`: bass vs residual;
- `other.pt`: other vs residual;
- opcional `accompaniment.pt`: accompaniment vs vocals.

Cada checkpoint padrao tem cerca de 2.84M parametros. O sistema completo pode usar 3 ou 4 modelos, mas a inferencia carrega um por vez, entao roda melhor em maquinas fracas do que um unico modelo grande.

## Por que isso deve melhorar sobre a v3

A v3 ja separa de verdade, mas ainda vaza beat em vocal quando voz e instrumento ocupam a mesma regiao tempo-frequencia. Na v4, o modelo de vocal treina somente a fronteira `voz` contra `acompanhamento`, com uma loss extra de silencio para reduzir energia quando nao existe voz. Isso e mais proximo da filosofia do Spleeter: um U-Net por instrumento/fonte.

O que entrou:

- mascara binaria `softmax`: target vs residual;
- U-Net espectral leve, parecida em espirito com Spleeter;
- contexto temporal dilatado no gargalo da mascara;
- feature de coordenada de frequencia para baixo/bumbo;
- contexto barato da waveform por FiLM;
- `target_silence` na loss para reduzir vazamento em trechos sem a fonte;
- export de modelos como `vocals.pt`, `drums.pt`, `bass.pt`, `other.pt`.

## Kaggle

Depois de subir `tiny-stem-mss-v4-clean.zip` para o GitHub:

```bash
%%bash
set -e

MSS_ZIP_URL="https://raw.githubusercontent.com/TsXK-shift/model-pt/main/tiny-stem-mss-v4-clean.zip" \
bash <(wget -qO- https://raw.githubusercontent.com/TsXK-shift/model-pt/main/mss_v4_stems/scripts/kaggle_setup_v4.sh)
```

Treinar todos os modelos principais:

```bash
%%bash
set -e

bash /kaggle/working/mss_v4_stems/scripts/kaggle_train_v4_stems.sh
```

Treinar so vocal primeiro:

```bash
%%bash
set -e

TARGETS="vocals" bash /kaggle/working/mss_v4_stems/scripts/kaggle_train_v4_stems.sh
```

Continuar automaticamente de `last.pt`:

```bash
%%bash
set -e

AUTO_RESUME=1 TARGETS="vocals drums bass other" \
bash /kaggle/working/mss_v4_stems/scripts/kaggle_train_v4_stems.sh
```

Exportar:

```bash
%%bash
set -e

bash /kaggle/working/mss_v4_stems/scripts/kaggle_export_models_v4.sh
```

## Inferencia

```bash
python scripts/separate_v4.py \
  --checkpoint-dir /kaggle/working/export_models-v4 \
  --input /kaggle/input/minha-musica/audio.wav \
  --out /kaggle/working/separated-v4 \
  --segment-seconds 8 \
  --overlap 0.5
```

Se `other.pt` nao existir, o script calcula `other = mixture - vocals - drums - bass` e aplica consistencia de mistura.

## Expectativa

O treino padrao vai ate 100 epochs por stem, com early stopping de 16 epochs sem melhora. Como sao modelos separados, o melhor caminho pratico e:

1. treinar `vocals` primeiro e testar;
2. treinar `drums` e `bass`;
3. treinar `other` por ultimo, ou usar residual se quiser economizar tempo.
