from __future__ import annotations

from typing import Sequence

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.checkpoint import checkpoint


def _group_count(channels: int) -> int:
    for groups in (8, 6, 4, 3, 2):
        if channels % groups == 0:
            return groups
    return 1


class ConvNormAct2d(nn.Module):
    def __init__(
        self,
        in_channels: int,
        out_channels: int,
        kernel_size: int = 3,
        stride: int = 1,
        dilation: int = 1,
    ) -> None:
        super().__init__()
        padding = dilation * (kernel_size // 2)
        self.net = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size, stride=stride, padding=padding, dilation=dilation),
            nn.GroupNorm(_group_count(out_channels), out_channels),
            nn.SiLU(),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


class StemResidualBlock2d(nn.Module):
    """Cheap residual block with depthwise context and a GLU gate."""

    def __init__(self, channels: int, dilation: int = 1, expansion: int = 2) -> None:
        super().__init__()
        hidden = channels * expansion
        self.norm = nn.GroupNorm(_group_count(channels), channels)
        self.in_proj = nn.Conv2d(channels, hidden * 2, kernel_size=1)
        self.depthwise = nn.Conv2d(
            hidden,
            hidden,
            kernel_size=5,
            padding=2 * dilation,
            dilation=dilation,
            groups=hidden,
        )
        self.out_proj = nn.Conv2d(hidden, channels, kernel_size=1)
        self.scale = nn.Parameter(torch.tensor(0.25))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        y = self.in_proj(F.silu(self.norm(x)))
        y = F.glu(y, dim=1)
        y = F.silu(self.depthwise(y))
        y = self.out_proj(y)
        return x + self.scale * y


class TemporalMaskBlock(nn.Module):
    """Dilated temporal context at the bottleneck.

    This is intentionally mask-domain, not waveform-domain. It improves continuity
    around vocal entries/exits without the memory cost of a time-domain refiner.
    """

    def __init__(self, channels: int, dilation: int, kernel_size: int = 7) -> None:
        super().__init__()
        padding = dilation * (kernel_size // 2)
        self.norm = nn.GroupNorm(_group_count(channels), channels)
        self.depthwise = nn.Conv2d(
            channels,
            channels * 2,
            kernel_size=(1, kernel_size),
            padding=(0, padding),
            dilation=(1, dilation),
            groups=channels,
        )
        self.pointwise = nn.Conv2d(channels, channels, kernel_size=1)
        self.scale = nn.Parameter(torch.tensor(0.2))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        y = self.depthwise(F.silu(self.norm(x)))
        y = F.glu(y, dim=1)
        y = self.pointwise(y)
        return x + self.scale * y


class WaveContext(nn.Module):
    def __init__(self, out_channels: int) -> None:
        super().__init__()
        widths = [24, 48, 80, out_channels]
        layers: list[nn.Module] = []
        in_channels = 2
        for width in widths:
            layers.extend(
                [
                    nn.Conv1d(in_channels, width, kernel_size=9, stride=4, padding=4),
                    nn.GroupNorm(_group_count(width), width),
                    nn.SiLU(),
                ]
            )
            in_channels = width
        self.encoder = nn.Sequential(*layers)
        self.to_film = nn.Conv1d(out_channels, out_channels * 2, kernel_size=1)

    def forward(self, mixture: torch.Tensor, frames: int) -> tuple[torch.Tensor, torch.Tensor]:
        context = self.encoder(mixture.float())
        context = F.interpolate(context, size=frames, mode="linear", align_corners=False)
        gamma, beta = self.to_film(context).chunk(2, dim=1)
        return gamma, beta


class TinyStemMSS(nn.Module):
    """Single-stem binary separator.

    Each checkpoint solves one easier task: target stem vs residual. A vocal model
    learns `vocals` against `accompaniment`; a drum model learns `drums` against
    everything else. This keeps each model small and makes silence/leakage control
    much easier than one 4-way model.
    """

    def __init__(
        self,
        sample_rate: int = 44100,
        sources: Sequence[str] = ("target", "residual"),
        target_source: str = "vocals",
        n_fft: int = 2048,
        hop_length: int = 512,
        win_length: int = 2048,
        base_channels: int = 32,
        channel_mults: Sequence[int] = (1, 2, 3, 4, 5),
        bottleneck_layers: int = 6,
        mask_temperature: float = 0.9,
        gradient_checkpointing: bool = True,
        **_: object,
    ) -> None:
        super().__init__()
        self.sample_rate = int(sample_rate)
        self.target_source = str(target_source)
        self.sources = list(sources)
        self.n_fft = int(n_fft)
        self.hop_length = int(hop_length)
        self.win_length = int(win_length)
        self.mask_temperature = float(mask_temperature)
        self.gradient_checkpointing = bool(gradient_checkpointing)
        self.register_buffer("window", torch.hann_window(self.win_length), persistent=False)

        widths = [base_channels * int(mult) for mult in channel_mults]
        self.in_proj = ConvNormAct2d(9, widths[0], kernel_size=5)

        self.encoders = nn.ModuleList()
        self.downs = nn.ModuleList()
        for level, width in enumerate(widths):
            dilation = 2 ** min(level, 4)
            self.encoders.append(
                nn.Sequential(
                    StemResidualBlock2d(width, dilation=1),
                    StemResidualBlock2d(width, dilation=dilation),
                )
            )
            if level < len(widths) - 1:
                self.downs.append(ConvNormAct2d(width, widths[level + 1], kernel_size=4, stride=2))

        bottleneck_width = widths[-1]
        self.wave_context = WaveContext(bottleneck_width)
        self.temporal = nn.Sequential(
            *[TemporalMaskBlock(bottleneck_width, dilation=2 ** (idx % 6)) for idx in range(bottleneck_layers)]
        )

        self.up_projs = nn.ModuleList()
        self.decoders = nn.ModuleList()
        current = bottleneck_width
        for skip_width in reversed(widths[:-1]):
            self.up_projs.append(ConvNormAct2d(current + skip_width, skip_width))
            self.decoders.append(
                nn.Sequential(
                    StemResidualBlock2d(skip_width),
                    StemResidualBlock2d(skip_width),
                )
            )
            current = skip_width

        self.mask_head = nn.Sequential(
            ConvNormAct2d(current, current),
            nn.Conv2d(current, 2 * 2, kernel_size=1),
        )

    def _maybe_checkpoint(self, module: nn.Module, x: torch.Tensor) -> torch.Tensor:
        if self.training and self.gradient_checkpointing and x.requires_grad:
            return checkpoint(module, x, use_reentrant=False)
        return module(x)

    def _stft(self, mixture: torch.Tensor) -> torch.Tensor:
        bsz, channels, frames = mixture.shape
        spec = torch.stft(
            mixture.float().reshape(bsz * channels, frames),
            n_fft=self.n_fft,
            hop_length=self.hop_length,
            win_length=self.win_length,
            window=self.window,
            center=True,
            return_complex=True,
        )
        return spec.reshape(bsz, channels, spec.shape[-2], spec.shape[-1])

    def _istft(self, spec: torch.Tensor, length: int) -> torch.Tensor:
        bsz, source_count, channels, freq, frames = spec.shape
        wav = torch.istft(
            spec.reshape(bsz * source_count * channels, freq, frames),
            n_fft=self.n_fft,
            hop_length=self.hop_length,
            win_length=self.win_length,
            window=self.window,
            center=True,
            length=length,
        )
        return wav.reshape(bsz, source_count, channels, length)

    def _features(self, spec: torch.Tensor) -> torch.Tensor:
        bsz, _, freq, frames = spec.shape
        mag = spec.abs().clamp_min(1e-8)
        phase = spec / mag
        compressed = mag.pow(0.3) * phase
        real_imag = torch.view_as_real(compressed).permute(0, 1, 4, 2, 3).reshape(
            bsz, spec.shape[1] * 2, freq, frames
        )
        logmag = torch.log1p(mag)
        mid = 0.5 * (spec[:, 0] + spec[:, 1])
        side = 0.5 * (spec[:, 0] - spec[:, 1])
        midside = torch.stack([torch.log1p(mid.abs()), torch.log1p(side.abs())], dim=1)
        freq_coord = torch.linspace(0, 1, freq, device=spec.device, dtype=logmag.dtype).view(1, 1, freq, 1)
        freq_coord = freq_coord.expand(bsz, 1, freq, frames)
        return torch.cat([real_imag, logmag, midside, freq_coord], dim=1)

    def forward(self, mixture: torch.Tensor) -> torch.Tensor:
        length = mixture.shape[-1]
        spec = self._stft(mixture)
        x = self.in_proj(self._features(spec))

        skips: list[torch.Tensor] = []
        for level, encoder in enumerate(self.encoders):
            x = self._maybe_checkpoint(encoder, x)
            skips.append(x)
            if level < len(self.downs):
                x = self.downs[level](x)

        gamma, beta = self.wave_context(mixture, x.shape[-1])
        x = x * (1.0 + gamma.unsqueeze(2)) + beta.unsqueeze(2)
        x = self._maybe_checkpoint(self.temporal, x)

        for up, decoder, skip in zip(self.up_projs, self.decoders, reversed(skips[:-1])):
            x = F.interpolate(x, size=skip.shape[-2:], mode="bilinear", align_corners=False)
            x = torch.cat([x, skip], dim=1)
            x = self._maybe_checkpoint(decoder, up(x))

        logits = self.mask_head(x)
        if logits.shape[-2:] != spec.shape[-2:]:
            logits = F.interpolate(logits, size=spec.shape[-2:], mode="bilinear", align_corners=False)

        bsz, _, freq, frames = logits.shape
        logits = logits.reshape(bsz, 2, 2, freq, frames)
        masks = torch.softmax(logits.float() / max(self.mask_temperature, 1e-4), dim=1)
        estimate_spec = masks.to(spec.real.dtype) * spec.unsqueeze(1)
        return self._istft(estimate_spec, length)


TinyHybridMSS = TinyStemMSS


def count_parameters(model: nn.Module) -> int:
    return sum(param.numel() for param in model.parameters() if param.requires_grad)
