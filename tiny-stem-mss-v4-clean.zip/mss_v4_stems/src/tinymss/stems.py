from __future__ import annotations

from typing import Sequence

import torch


def stem_names_for_target(target_source: str) -> list[str]:
    target_source = target_source.lower()
    if target_source == "accompaniment":
        return ["accompaniment", "vocals"]
    return [target_source, "residual"]


def make_binary_stems(stems: torch.Tensor, source_names: Sequence[str], target_source: str) -> torch.Tensor:
    """Convert MUSDB 4-stem tensor to [target, residual].

    Args:
        stems: tensor shaped [B, S, C, T] or [S, C, T].
        source_names: source order used by the dataset.
        target_source: vocals, drums, bass, other, or accompaniment.
    """
    target_source = target_source.lower()
    names = [name.lower() for name in source_names]
    original_dim = stems.dim()
    if original_dim == 3:
        stems = stems.unsqueeze(0)
    if stems.dim() != 4:
        raise ValueError(f"Expected stems with 3 or 4 dims, got {tuple(stems.shape)}")

    if target_source == "accompaniment":
        if "vocals" not in names:
            raise ValueError("accompaniment target requires a vocals source")
        vocal_idx = names.index("vocals")
        vocals = stems[:, vocal_idx]
        accompaniment = stems.sum(dim=1) - vocals
        out = torch.stack([accompaniment, vocals], dim=1)
    else:
        if target_source not in names:
            raise ValueError(f"Unknown target_source={target_source!r}; available={list(source_names)}")
        target_idx = names.index(target_source)
        target = stems[:, target_idx]
        residual = stems.sum(dim=1) - target
        out = torch.stack([target, residual], dim=1)

    return out[0] if original_dim == 3 else out
