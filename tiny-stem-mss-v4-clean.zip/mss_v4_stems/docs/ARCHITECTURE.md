# Tiny Stem MSS v4 Architecture

## Goal

v3 proved that competitive masks are the right direction, but a 4-way mask still asks one small model to decide vocals, drums, bass and other at once. v4 splits that task into specialist checkpoints.

Each model predicts two sources:

```text
target stem + residual = mixture
```

Examples:

```text
vocals.pt: vocals + accompaniment
drums.pt:  drums  + not-drums
bass.pt:   bass   + not-bass
other.pt:  other  + not-other
```

## Model

- stereo STFT frontend;
- compressed real/imag phase features;
- left/right log magnitude;
- mid/side log magnitude;
- normalized frequency coordinate;
- small U-Net encoder/decoder;
- depthwise-separable residual blocks;
- dilated temporal mask blocks at the bottleneck;
- waveform FiLM context;
- target/residual softmax masks.

Default size: about 2.84M trainable parameters per checkpoint.

## Loss

The binary target makes the ratio-mask objective cleaner. v4 also adds `target_silence`, which penalizes energy in the target output when the true target is quiet. This is aimed directly at vocal leakage and the "voice cuts in/out but beat stays behind it" failure.

## Inference

`separate_v4.py` loads each target checkpoint sequentially, writes its target stem, and then enforces mixture consistency. If `other.pt` is unavailable, `other` is computed as the residual after vocals, drums and bass.
