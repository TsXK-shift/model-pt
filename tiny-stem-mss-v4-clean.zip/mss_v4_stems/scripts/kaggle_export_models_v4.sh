#!/usr/bin/env bash
set -euo pipefail

RUN_ROOT="${RUN_ROOT:-/kaggle/working/runs/tiny-stem-v4}"
PROJECT_DIR="${PROJECT_DIR:-/kaggle/working/mss_v4_stems}"
LOG_DIR="${LOG_DIR:-/kaggle/working/logs}"
EXPORT_DIR="${EXPORT_DIR:-/kaggle/working/export_models-v4}"
ZIP_PATH="${ZIP_PATH:-/kaggle/working/tiny-stem-models-v4.zip}"
TARGETS="${TARGETS:-vocals drums bass other}"

rm -rf "${EXPORT_DIR}"
rm -f "${ZIP_PATH}"
mkdir -p "${EXPORT_DIR}/logs"

for TARGET in ${TARGETS}; do
  BEST="${RUN_ROOT}/${TARGET}/checkpoints/best.pt"
  LAST="${RUN_ROOT}/${TARGET}/checkpoints/last.pt"
  if [ -f "${BEST}" ]; then
    cp "${BEST}" "${EXPORT_DIR}/${TARGET}.pt"
  fi
  if [ -f "${LAST}" ]; then
    cp "${LAST}" "${EXPORT_DIR}/${TARGET}-last.pt"
  fi
  cp "${RUN_ROOT}/${TARGET}/resolved_config.json" "${EXPORT_DIR}/${TARGET}-resolved_config.json" 2>/dev/null || true
  cp "${LOG_DIR}/train_v4_${TARGET}.log" "${EXPORT_DIR}/logs/train_v4_${TARGET}.log" 2>/dev/null || true
done

cp "${PROJECT_DIR}/configs/kaggle_t4x2.yaml" "${EXPORT_DIR}/kaggle_t4x2.yaml"

cd /kaggle/working
zip -r "$(basename "${ZIP_PATH}")" "$(basename "${EXPORT_DIR}")"
ls -lh "${ZIP_PATH}"
