from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import time
import urllib.error
import urllib.request
import zipfile
from pathlib import Path


def read_paths() -> tuple[Path | None, Path | None]:
    path_file = Path("/content/tinymss_paths.json")
    if not path_file.exists():
        return None, None
    data = json.loads(path_file.read_text(encoding="utf-8"))
    project = Path(data["PROJECT"]) if data.get("PROJECT") else None
    ckpt_dir = Path(data["CKPT_DIR"]) if data.get("CKPT_DIR") else None
    return project, ckpt_dir


def parse_train_log(path: Path) -> dict:
    if not path.exists():
        return {"available": False, "path": str(path), "epochs": []}
    text = path.read_text(encoding="utf-8", errors="replace")
    rows = []
    pattern = re.compile(
        r"epoch=(\d+) train_loss=([0-9.]+) valid_loss=([0-9.]+) valid_si_sdr=([-0-9.]+)dB"
    )
    for match in pattern.finditer(text):
        rows.append(
            {
                "epoch": int(match.group(1)),
                "train_loss": float(match.group(2)),
                "valid_loss": float(match.group(3)),
                "valid_si_sdr": float(match.group(4)),
            }
        )
    steps = re.findall(r"epoch=(\d+) step=(\d+)/(\d+)", text)
    return {
        "available": True,
        "path": str(path),
        "epoch_rows": len(rows),
        "last_epoch": rows[-1] if rows else None,
        "best_valid_loss": min(rows, key=lambda row: row["valid_loss"]) if rows else None,
        "best_valid_si_sdr": max(rows, key=lambda row: row["valid_si_sdr"]) if rows else None,
        "last_step": {
            "epoch": int(steps[-1][0]),
            "step": int(steps[-1][1]),
            "total": int(steps[-1][2]),
        }
        if steps
        else None,
        "errors": {
            "traceback": "Traceback" in text,
            "out_of_memory": "OutOfMemory" in text or "CUDA out of memory" in text,
            "runtime_error": "RuntimeError" in text,
            "nan": bool(re.search(r"\bnan\b", text, re.IGNORECASE)),
        },
    }


def fetch_json(url: str) -> dict | None:
    try:
        with urllib.request.urlopen(url, timeout=3) as response:
            return json.loads(response.read().decode("utf-8"))
    except (OSError, urllib.error.URLError, TimeoutError, json.JSONDecodeError):
        return None


def add_file(zf: zipfile.ZipFile, path: Path, arcname: str) -> None:
    if path.exists() and path.is_file():
        zf.write(path, arcname)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project", default=None)
    parser.add_argument("--checkpoint-dir", default=None)
    parser.add_argument("--out", default="/content/tinymss-debug-logs.zip")
    args = parser.parse_args()

    project, ckpt_dir = read_paths()
    if args.project:
        project = Path(args.project)
    if args.checkpoint_dir:
        ckpt_dir = Path(args.checkpoint_dir)

    if project is None:
        project = Path.cwd()
    if ckpt_dir is None:
        for candidate in (
            project / "export_checkpoint-v3",
            project / "export-checkpoint-v3",
            project / "export_checkpoint",
        ):
            if candidate.exists():
                ckpt_dir = candidate
                break

    out = Path(args.out)
    work = Path("/content/tinymss-debug-export")
    if work.exists():
        shutil.rmtree(work)
    work.mkdir(parents=True, exist_ok=True)

    manifest = {
        "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "project": str(project),
        "checkpoint_dir": str(ckpt_dir) if ckpt_dir else None,
        "env": {
            "TINYMSS_CHECKPOINT_DIRS": os.environ.get("TINYMSS_CHECKPOINT_DIRS"),
            "TINYMSS_TRAIN_LOG": os.environ.get("TINYMSS_TRAIN_LOG"),
            "TINYMSS_WEB_WORKDIR": os.environ.get("TINYMSS_WEB_WORKDIR"),
        },
    }

    train_candidates = []
    if ckpt_dir is not None:
        train_candidates.append(ckpt_dir / "train_v3.log")
        train_candidates.append(ckpt_dir / "train_watch.log")
    train_candidates.extend(
        [
            project / "logs" / "train_v3.log",
            project / "logs" / "train_watch.log",
            project / "export_checkpoint-v3" / "train_v3.log",
            project / "export-checkpoint-v3" / "train_v3.log",
        ]
    )
    train_log = next((path for path in train_candidates if path.exists()), None)
    if train_log:
        manifest["train_log_summary"] = parse_train_log(train_log)

    server_status = fetch_json("http://127.0.0.1:7860/api/status")
    checkpoints = fetch_json("http://127.0.0.1:7860/api/checkpoints")
    training_summary = fetch_json("http://127.0.0.1:7860/api/training-summary")
    if server_status:
        manifest["server_status"] = server_status
    if checkpoints:
        manifest["server_checkpoints"] = checkpoints
    if training_summary:
        manifest["server_training_summary"] = training_summary

    (work / "manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")

    if out.exists():
        out.unlink()
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.write(work / "manifest.json", "manifest.json")
        for idx, path in enumerate(train_candidates):
            if path.exists():
                add_file(zf, path, f"logs/train_{idx}_{path.name}")
        for path in (
            Path("/content/tinymss_server.log"),
            project / "web_server.out.log",
            project / "web_server.err.log",
            project / "configs" / "kaggle_t4x2.yaml",
        ):
            add_file(zf, path, f"files/{path.name}")
        if ckpt_dir is not None:
            for path in ckpt_dir.glob("*.json"):
                add_file(zf, path, f"checkpoint/{path.name}")
            for path in ckpt_dir.glob("*.yaml"):
                add_file(zf, path, f"checkpoint/{path.name}")

    print(out)
    print(f"{out.stat().st_size / 1024:.1f} KiB")


if __name__ == "__main__":
    main()
