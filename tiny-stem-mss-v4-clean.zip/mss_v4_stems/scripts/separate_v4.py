from __future__ import annotations

import argparse
import sys
from pathlib import Path

import torch
from tqdm.auto import tqdm

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from tinymss.audio import crop_or_pad, load_audio, peak_normalize, save_audio
from tinymss.model import TinyStemMSS


def load_checkpoint(path: Path, device: torch.device) -> tuple[TinyStemMSS, dict]:
    try:
        checkpoint = torch.load(path, map_location=device, weights_only=False)
    except TypeError:
        checkpoint = torch.load(path, map_location=device)
    cfg = checkpoint["config"]
    model = TinyStemMSS(**cfg["model"]).to(device)
    state = dict(checkpoint["model"])
    ema_state = checkpoint.get("ema")
    if ema_state and ema_state.get("shadow"):
        state.update(ema_state["shadow"])
    model.load_state_dict(state)
    model.eval()
    return model, cfg


def checkpoint_for_target(checkpoint_dir: Path, target: str) -> Path | None:
    candidates = [
        checkpoint_dir / f"{target}.pt",
        checkpoint_dir / target / "checkpoints" / "best.pt",
        checkpoint_dir / target / "best.pt",
        checkpoint_dir / f"{target}-best.pt",
    ]
    return next((path for path in candidates if path.exists()), None)


@torch.no_grad()
def apply_target_model(
    model: TinyStemMSS,
    mixture: torch.Tensor,
    segment_frames: int,
    overlap: float,
    device: torch.device,
    amp: bool,
) -> torch.Tensor:
    channels, total_frames = mixture.shape
    hop = max(1, int(round(segment_frames * (1.0 - overlap))))
    window = torch.hann_window(segment_frames, periodic=False).clamp_min(1e-4)
    out = torch.zeros(channels, total_frames + segment_frames)
    weight = torch.zeros(1, total_frames + segment_frames)
    starts = list(range(0, total_frames, hop))

    for start in tqdm(starts, desc=f"{model.target_source}"):
        chunk = crop_or_pad(mixture[:, start : start + segment_frames], segment_frames)
        with torch.autocast(device_type="cuda", enabled=amp and device.type == "cuda"):
            estimate = model(chunk.unsqueeze(0).to(device))[0, 0].float().cpu()
        end = start + segment_frames
        out[:, start:end] += estimate * window.view(1, -1)
        weight[:, start:end] += window.view(1, -1)

    return out[:, :total_frames] / weight[:, :total_frames].clamp_min(1e-6)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--checkpoint-dir", required=True)
    parser.add_argument("--input", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--targets", nargs="+", default=["vocals", "drums", "bass", "other"])
    parser.add_argument("--segment-seconds", type=float, default=8.0)
    parser.add_argument("--overlap", type=float, default=0.5)
    parser.add_argument("--no-amp", action="store_true")
    parser.add_argument("--normalize", action="store_true")
    parser.add_argument("--no-consistency", action="store_true")
    args = parser.parse_args()

    checkpoint_dir = Path(args.checkpoint_dir)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    loaded: dict[str, tuple[TinyStemMSS, dict, Path]] = {}
    for target in args.targets:
        path = checkpoint_for_target(checkpoint_dir, target)
        if path is None:
            print(f"warning: no checkpoint for {target} in {checkpoint_dir}")
            continue
        model, cfg = load_checkpoint(path, device)
        loaded[target] = (model, cfg, path)

    if not loaded:
        raise FileNotFoundError(f"No target checkpoints found in {checkpoint_dir}")

    sample_rate = int(next(iter(loaded.values()))[1]["model"]["sample_rate"])
    mixture = load_audio(args.input, sample_rate)
    segment_frames = int(round(args.segment_seconds * sample_rate))

    estimates: dict[str, torch.Tensor] = {}
    for target, (model, _, path) in loaded.items():
        print(f"using {target}: {path}")
        estimates[target] = apply_target_model(
            model=model,
            mixture=mixture,
            segment_frames=segment_frames,
            overlap=args.overlap,
            device=device,
            amp=not args.no_amp,
        )
        model.to("cpu")
        if device.type == "cuda":
            torch.cuda.empty_cache()

    if "other" not in estimates:
        if "accompaniment" in estimates:
            other = estimates["accompaniment"].clone()
            for name in ("drums", "bass"):
                if name in estimates:
                    other = other - estimates[name]
            estimates["other"] = other
        else:
            known = torch.zeros_like(mixture)
            for name in ("vocals", "drums", "bass"):
                if name in estimates:
                    known = known + estimates[name]
            estimates["other"] = mixture - known

    output_order = [name for name in ("vocals", "drums", "bass", "other") if name in estimates]
    if not args.no_consistency and output_order:
        stack = torch.stack([estimates[name] for name in output_order], dim=0)
        residual = mixture - stack.sum(dim=0)
        if "other" in output_order:
            stack[output_order.index("other")] += residual
        else:
            stack += residual.unsqueeze(0) / len(output_order)
        for idx, name in enumerate(output_order):
            estimates[name] = stack[idx]

    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)
    for name in output_order:
        wav = estimates[name]
        if args.normalize:
            wav = peak_normalize(wav)
        save_audio(out_dir / f"{name}.wav", wav, sample_rate)


if __name__ == "__main__":
    main()
