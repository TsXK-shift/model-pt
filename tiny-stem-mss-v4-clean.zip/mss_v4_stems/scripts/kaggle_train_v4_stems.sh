#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="${PROJECT_DIR:-/kaggle/working/mss_v4_stems}"
MUSDB_DIR="${MUSDB_DIR:-/tmp/musdb18hq}"
RUN_ROOT="${RUN_ROOT:-/kaggle/working/runs/tiny-stem-v4}"
LOG_DIR="${LOG_DIR:-/kaggle/working/logs}"
TARGETS="${TARGETS:-vocals drums bass other}"
NPROC="${NPROC:-2}"
AUTO_RESUME="${AUTO_RESUME:-1}"

if [ ! -f "${PROJECT_DIR}/scripts/train_watch.py" ]; then
  echo "ERROR: train_watch.py not found in ${PROJECT_DIR}. Run kaggle_setup_v4.sh first."
  exit 1
fi

if [ ! -d "${MUSDB_DIR}/train" ] || [ ! -d "${MUSDB_DIR}/test" ]; then
  echo "ERROR: MUSDB18-HQ not found in ${MUSDB_DIR}. Run kaggle_setup_v4.sh first."
  exit 1
fi

mkdir -p "${RUN_ROOT}" "${LOG_DIR}"
cd "${PROJECT_DIR}"

export PYTHONUNBUFFERED=1
export SIMPLE_LOG="${SIMPLE_LOG:-1}"
export PROGRESS_EVERY="${PROGRESS_EVERY:-5}"
export PYTORCH_CUDA_ALLOC_CONF="${PYTORCH_CUDA_ALLOC_CONF:-expandable_segments:True}"

for TARGET in ${TARGETS}; do
  OUT_DIR="${RUN_ROOT}/${TARGET}"
  LOG_FILE="${LOG_DIR}/train_v4_${TARGET}.log"
  mkdir -p "${OUT_DIR}/checkpoints"

  args=(
    --config configs/kaggle_t4x2.yaml
    --data "${MUSDB_DIR}"
    --out "${OUT_DIR}"
    --target "${TARGET}"
  )

  if [ "${AUTO_RESUME}" = "1" ] && [ -f "${OUT_DIR}/checkpoints/last.pt" ]; then
    args+=(--resume "${OUT_DIR}/checkpoints/last.pt")
    echo "Resuming ${TARGET} from ${OUT_DIR}/checkpoints/last.pt"
  else
    echo "Starting ${TARGET} from zero"
  fi

  echo "Target:  ${TARGET}"
  echo "Output:  ${OUT_DIR}"
  echo "Log:     ${LOG_FILE}"

  torchrun --nproc_per_node="${NPROC}" scripts/train_watch.py "${args[@]}" 2>&1 | tee -a "${LOG_FILE}"
done
